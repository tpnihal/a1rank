import { NextResponse } from "next/server";
import { sendMail } from "@/lib/mailer";
import { INTERESTS, PACKAGES, SITE, WEBSITE_INTEREST, WEBSITE_PLANS } from "@/lib/site";

export const runtime = "nodejs";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const WINDOW_MS = 10 * 60 * 1000;
const MAX_PER_WINDOW = 5;
const hits = new Map<string, number[]>();

/** Small in-memory limiter. Good for a single server; Stage 4 moves rate limiting to a shared store. */
function limited(ip: string) {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_PER_WINDOW) {
    hits.set(ip, recent);
    return true;
  }
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 5000) hits.clear();
  return false;
}

const esc = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);
const str = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

export async function POST(req: Request) {
  const ip = (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || "unknown";
  if (limited(ip)) {
    return NextResponse.json({ error: "Too many requests. Please try again in a few minutes." }, { status: 429 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  // Bots fill the hidden field. Pretend it worked and send nothing.
  if (str(body.hp, 200)) return NextResponse.json({ ok: true });

  const type = body.type === "newsletter" ? "newsletter" : "enquiry";
  const email = str(body.email, 200);
  if (!EMAIL_RE.test(email)) {
    return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  }

  let subject: string;
  let rows: [string, string][];

  if (type === "newsletter") {
    subject = "New newsletter subscriber";
    rows = [["Email", email]];
  } else {
    const name = str(body.name, 120);
    if (name.length < 2) return NextResponse.json({ error: "Please add your name." }, { status: 400 });
    let interests = Array.isArray(body.interests)
      ? body.interests.filter((i): i is string => typeof i === "string" && INTERESTS.includes(i))
      : [];
    // One enquiry is either a website project or monthly marketing, never both.
    const websiteMode = interests.includes(WEBSITE_INTEREST);
    if (websiteMode) interests = [WEBSITE_INTEREST];
    const chosen = str(body.package, 40);
    const plan = websiteMode ? WEBSITE_PLANS.find((p) => p.name === chosen) : undefined;
    const monthly = websiteMode ? undefined : PACKAGES.find((p) => p.name === chosen);
    const pkg = plan ? `${plan.name} website plan` : monthly?.name ?? "Not chosen";
    subject = `New enquiry from ${name}${pkg !== "Not chosen" ? ` (${pkg})` : ""}`;
    rows = [
      ["Topic", str(body.topic, 120) || "General enquiry"],
      ["Name", name],
      ["Business", str(body.company, 160)],
      ["Email", email],
      ["WhatsApp / phone", str(body.phone, 40)],
      ["Website", str(body.website, 300)],
      [websiteMode ? "Website plan" : "Package", plan ? `${plan.name} (${plan.from ? "from " : ""}AED ${plan.price.toLocaleString("en-US")}, one-time)` : monthly ? `${monthly.name} (${monthly.from ? "from " : ""}AED ${monthly.price.toLocaleString("en-US")}/month)` : pkg],
      ["Interested in", interests.join(", ")],
      ["Goals", str(body.message, 4000)],
    ];
  }

  const html = `<table cellpadding="8" style="font-family:Arial,sans-serif;font-size:14px;border-collapse:collapse">${rows
    .filter(([, v]) => v)
    .map(
      ([k, v]) =>
        `<tr><td style="color:#6a5f62;vertical-align:top;border-bottom:1px solid #eee"><b>${esc(k)}</b></td><td style="border-bottom:1px solid #eee;white-space:pre-wrap">${esc(v)}</td></tr>`,
    )
    .join("")}</table>`;

  const result = await sendMail({ subject: `[${SITE.domain}] ${subject}`, html, replyTo: email }, "enquiry");
  if (result === "not_configured") {
    console.warn("[enquiry] No email delivery configured (SMTP_PASS, or RESEND_API_KEY + ENQUIRY_FROM); message was not delivered.");
    return NextResponse.json({ error: "Our online form is not connected to email yet." }, { status: 503 });
  }
  if (result === "failed") {
    return NextResponse.json({ error: "We could not send your message right now." }, { status: 502 });
  }

  return NextResponse.json({ ok: true });
}
